package folderUpload.constants;

/**
 * @author naveen
 */
public class FolderUploadPortletKeys {

	public static final String FOLDERUPLOAD =
		"folderUpload_FolderUploadPortlet";

}