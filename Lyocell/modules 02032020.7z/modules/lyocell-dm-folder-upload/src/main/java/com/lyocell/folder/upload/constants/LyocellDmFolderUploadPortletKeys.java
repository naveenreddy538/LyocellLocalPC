package com.lyocell.folder.upload.constants;

/**
 * @author naveen_vanakuru
 */
public class LyocellDmFolderUploadPortletKeys {

	public static final String LYOCELLDMFOLDERUPLOAD =
		"com_lyocell_folder_upload_LyocellDmFolderUploadPortlet";
	public static final String FILEUPLOADFOLDERDESC ="This folder is create using Upload Folder";	

}